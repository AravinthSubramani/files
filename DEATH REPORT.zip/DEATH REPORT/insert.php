<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

<table><?php   
if(isset($_POST['submit']))
{
$server="localhost";
$user="root";
$pass="root";
$con=new mysqli($server,$user,$pass); 
$aadhar=$_POST['ano'];
$pname=$_POST['pna'];
$fname=$_POST['fna'];
$hname=$_POST['hna'];
$dob=$_POST['dob'];
$age=$_POST['age'];
$dod=$_POST['dod'];     
$gender=$_POST['gen'];
$pod=$_POST['pod'];
$dno=$_POST['dno'];
$post=$_POST['post'];
$taluk=$_POST['tal'];
$district=$_POST['dis'];
$state=$_POST['sta'];
$pincode=$_POST['pcde'];
if(mysqli_connect_error())
{
    die('Connect Error('.mysqli_connect_error().')'.mysqli_connect_error());
}
else
{
        $check=mysqli_query($con,"SELECT adharno FROM report.register WHERE adharno='$aadhar'") or die("could not execute query:".mysqli_error($con));
        if(mysqli_num_rows($check)>0)
        {
            echo "<h1> Aadhar Numeber Already Registered </h1>";
        }
        else
        {
        $query="INSERT INTO report.register(adharno,person,father,husband,dateofb,age,death,gender,place,doorno,post,taluk,dis,sta,pin)VALUES('$aadhar','$pname','$fname','$hname','$dob','$age','$dod','$gender','$pod','$dno','$post','$taluk','$district','$state','$pincode')" ;
           $asd=mysqli_query($con,$query);
             if($asd)
             {
             echo "<h1>Application Number:</h1>". mysqli_insert_id($con); 
             }
             else
             {
             header("location:death.html");
             }
         }      
}
}
?> 
 </table>
</body>
</html>