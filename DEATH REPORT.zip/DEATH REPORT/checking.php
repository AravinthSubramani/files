<?php
session_start();
if(isset($_POST['search']))
{
$server="localhost";
$user="root";
$pass="root";
$con=new mysqli($server,$user,$pass);
$id=$_POST['id1'];
$_SESSION['appno']=$id;
$result=mysqli_query($con,"SELECT appno FROM report.register WHERE appno='$id'") or die("could not execute query:".mysqli_error($con));
$ch=mysqli_fetch_assoc($result);
if($ch)
{
    header("location:table.php");
}
else
{
    echo("<script>
                    alert('Appliction Number unavailable');</script>");

}
}
?>