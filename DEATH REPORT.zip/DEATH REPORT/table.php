<html>
<head>
    <style type="text/css">
        td,th{
          height: 40px;
            width: 330px;
        }
    </style>
    </head>
<body style="background-color:black;color:orange;font-family:constantia;font-size:22px;">
    <hr/>
    <h2 style="text-align:center;font-family:serif;color:yellow;font-size:40px">DEATH REPORT OF TAMILNADU</h2><hr/><br/>
    <h2 style="text-align:center;color:skyblue;font-family:constantia;font-size:24px;text-decoration:underline;">For Given Application Number the details are below</h2><br/>
    <table align="center" border="2" style="font-size:22px;">
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$conn = mysqli_connect($servername, $username, $password);
$id=$_SESSION['appno'];
$result=mysqli_query($conn,"SELECT appno FROM report.register WHERE appno='$id'") or die("could not execute query:".mysqli_error($conn));
$ch=mysqli_fetch_assoc($result);
?>
<?php
if($ch)
{
    $sql = "SELECT * FROM report.register WHERE appno='$id'";
    $result11 = mysqli_query($conn, $sql);
  //  echo "<table>";
    while($row=$result11->fetch_assoc())
    {
?>
    <?php echo "<tr>";?>
        <th>Application No </th>
        <td width="500"> <?php echo $row['appno'];?> </td>
     <?php echo "</tr>";?> 
    <?php echo "<tr>";?>
        <th>Aadhar No </th>
        <td width="500"> <?php echo $row['adharno'];?> </td>
     <?php echo "</tr>";?>   
     <?php echo "<tr>";?>
     <th>Person Name</th>
        <td> <?php echo $row['person'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
    <th>Father Name </th>
        <td> <?php echo $row['father'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>Mother Name</th>
        <td> <?php echo $row['husband'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>Date of Birth</th>
        <td> <?php echo $row['dateofb'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>Age</th>
        <td> <?php echo $row['age'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>Date of Death</th>
        <td> <?php echo $row['death'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>Gender</th>
        <td> <?php echo $row['gender'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>Place of Death</th>
        <td> <?php echo $row['place'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>Door No</th>
        <td> <?php echo $row['doorno'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>Post</th>
        <td> <?php echo $row['post'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>Taluk</th>
        <td> <?php echo $row['taluk'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>District</th>
        <td> <?php echo $row['dis'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>State</th>
        <td> <?php echo $row['sta'];?> </td>
        <?php echo "</tr>";?> 
        <?php echo "<tr>";?>
        <th>pincode</th>
        <td> <?php echo $row['pin'];?> </td>
    <?php echo "</tr>";?>
    <?php
    }
}
    ?>
</table></body>
</html>