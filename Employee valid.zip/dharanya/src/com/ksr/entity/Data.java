package com.ksr.entity;

public class Data {
   private int d;
   private String s;
public int getD() {
	return d;
}
public void setD(int d) {
	this.d = d;
}
public String getS() {
	return s;
}
public void setS(String s) {
	this.s = s;
}

}
