package com.ksr.service;

import com.ksr.entity.*;
import com.ksr.count.*;

public class Validate {
	String res1="Mindigit:",res2="firstCharacter:",result;
	Count c=new Count();
	public String validateinput(Data d)
	{
		try{
		if(d.getD()<0)
		{
			throw new InvalidInputException();
		}
		else
		{
			res1=res1+String.valueOf(c.mindigit(d.getD()));
		}
		}
		catch(InvalidInputException e)
		{
               res1=res1+e.toString("Invalid Number");
		}
		try
		{
		if(d.getS().equals(""))
		{
			throw new InvalidInputException();
		}
		else
		{
            res2=res2+String.valueOf(c.firstcharacter(d.getS()));
		}
		}
		catch(InvalidInputException e1)
		{
			res2=res2+e1.toString("Empty");
		}
		result=res1+","+res2;
		return result;
	}

}
