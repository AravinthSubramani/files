package com.ksr.main;
import com.ksr.entity.*;
import com.ksr.service.*;
import java.util.*;
public class TestMain {
    public static void main(String args[]){
    	Scanner sc=new Scanner(System.in);
    	int num=sc.nextInt();
    	sc.nextLine();
    	String str=sc.nextLine();
    	Data dd=new Data();
    	dd.setD(num);
    	dd.setS(str);
    	Validate v=new Validate();
    	System.out.print(v.validateinput(dd));
    	sc.close();
}
}
