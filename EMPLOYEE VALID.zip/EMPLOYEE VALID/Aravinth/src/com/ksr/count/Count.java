package com.ksr.count;

public class Count {
	public int mindigit(int d)
	{
		int m=d%10;d=d/10;
		while(d!=0)
		{
			int r=d%10;
			if(r<m)
			{
				m=r;
			}
			d=d/10;
		}
		return m;
	}
	public char firstcharacter(String s)
	{
		 char c = 0;
		 for(int i=0;i<s.length();i++)
		 {
			 int flag=0;
			 for(int j=0;j<s.length();j++)
			 {
				 if(s.charAt(i)==s.charAt(j) && (i!=j))
				 {
					 flag=1;
					 break;
				 }
			 }
			 if(flag==0)
			 {
				 c=s.charAt(i);
				 break;
			 }
		 }
		 return c;
	}
}
